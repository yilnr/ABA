import torch
import torch.nn as nn
import torch.nn.functional as F
from .cav_mae import CAVMAEFT
from .m3ae import MaskedMultimodalAutoencoder as M3AE
import pickle
import pdb
import einops
from ml_collections import ConfigDict

import torch
import torch.nn as nn
import torch.nn.functional as F

class Modal3Classifier(nn.Module):
    def __init__(self):
        super(Modal3Classifier, self).__init__()
        n_classes = 4
        model_config = ConfigDict(dict(model_type='base'))
        self.mae_a = CAVMAEFT(n_classes)
        self.mae_v = M3AE(text_vocab_size = 30522, config_updates = model_config)
        self.mae_t = M3AE(text_vocab_size = 30522, config_updates = model_config)
        
        cav_ckpt_audio = "/data/zyh/dataset/precessed/vgg_66.0.pth"
        sdA_audio = torch.load(cav_ckpt_audio)
        new_sdA_audio = {k.replace("module.", ""): v for k, v in sdA_audio.items()}
        miss, unexcepted = self.mae_a.load_state_dict(new_sdA_audio, strict=False)
        self.mae_a = self.mae_a.cuda() 


        m3ae_ckpt = "/data/zyh/dataset/precessed/torch_m3ae_base.pth"
        sdA_visual = torch.load(m3ae_ckpt) 
        self.mae_v.load_state_dict(sdA_visual)
        self.mae_v = self.mae_v.cuda() 

        sdA_text = torch.load(m3ae_ckpt)
        self.mae_t.load_state_dict(sdA_text)
        self.mae_t = self.mae_t.cuda()

        self.audio_fc = nn.Linear(768, n_classes)
        self.visual_fc = nn.Linear(768, n_classes)
        self.txtual_fc = nn.Linear(768, n_classes)


        # self.shared = nn.Linear(768, n_classes)
        

        
    def forward(self, token, padding_mask, visual, audio, return_feature=True):
        
        visual = einops.rearrange(visual, 
            'b c (h p1) (w p2) -> b (h w) (c p1 p2)',
            p1 = 16, p2 = 16)

        token = token.squeeze(1)
        padding_mask = padding_mask.squeeze(1)

        a = self.mae_a.forward_feat(audio, None, "a")
        v = self.mae_v.forward_representation(visual, None, None)
        
        t = self.mae_t.forward_representation(None, token, padding_mask)
        
        a = a.mean(dim = 1)
        v = v.mean(dim = 1)
        t = t.mean(dim = 1)

        a_o = self.audio_fc(a)
        v_o = self.visual_fc(v)
        t_o = self.txtual_fc(t)

        ### ORI have it  
        # a_f = self.shared(a)
        # v_f = self.shared(v)
        # t_f = self.shared(t)
        if return_feature:
            return a_o, v_o, t_o, a, v, t
        else:
            return a_o, v_o, t_o
        # return a_o, v_o, t_o, a_f, v_f, t_f

    def clssifier(self, audio_embs, video_embs, depth_embs):
        a_o = self.audio_fc(audio_embs)
        v_o = self.visual_fc(video_embs)
        t_o = self.txtual_fc(depth_embs)
        return a_o, v_o, t_o

