import copy
import csv
import os
import pickle
import numpy as np

import torch
from PIL import Image
import PIL
from torch.utils.data import Dataset
from torchvision import transforms
import pdb
from timm.data import create_transform
from sklearn.preprocessing import OneHotEncoder
from numpy.random import randint

class Modal3Dataset(Dataset):

    def __init__(self, mode='train'):
        classes = []
        data = []
        data2class = {}
        self.mode = mode
        # self.augnois = args.cav_augnois
        self.data_root = '/data/zyh/dataset/precessed/'
        self.visual_feature_path = os.path.join(self.data_root, "visual", '{}_imgs/'.format(mode))
        self.text_feature_path = os.path.join(self.data_root, "text_token", '{}_token/'.format(mode))
        self.audio_feature_path = os.path.join(self.data_root, "audio", '{}_fbank/'.format(mode))
        self.stat_path = "/data/zyh/dataset/precessed/stat_iemo.txt"
        self.train_txt = "/data/zyh/dataset/precessed/my_train_iemo.txt"
        self.test_txt = "/data/zyh/dataset/precessed/my_test_iemo.txt"

        with open(self.stat_path, "r") as f1:
            classes = f1.readlines()
        
        classes = [sclass.strip() for sclass in classes]

        if mode == 'train':
            csv_file = self.train_txt
        else:
            csv_file = self.test_txt

        with open(csv_file, "r") as f2:
            csv_reader = f2.readlines()
            for single_line in csv_reader:
                item = single_line.strip().split(" [split|sign] ")
                item[0] = item[0].split(".mp4")[0]
                token_path = os.path.join(self.text_feature_path, item[0] + '_token.npy')
                pm_path = os.path.join(self.text_feature_path, item[0] + '_pm.npy')
                visual_path = os.path.join(self.visual_feature_path, item[0])
                audio_path = os.path.join(self.audio_feature_path, item[0] + '.npy')
                # pdb.set_trace()
                if os.path.exists(token_path) and os.path.exists(visual_path) and os.path.exists(audio_path):
                    data.append(item[0])
                    data2class[item[0]] = item[-1]
                else:
                    continue

        self.classes = sorted(classes)

        print(self.classes)
        self.data2class = data2class

        self.av_files = []
        for item in data:
            self.av_files.append(item)
        print('# of files = %d ' % len(self.av_files))
        print('# of classes = %d' % len(self.classes))

        self.preprocess_train = create_transform(
                input_size = 256,
                is_training=True,
                color_jitter = True,
                auto_augment = None,
                interpolation = "bicubic",
                re_prob = 0,
                re_mode = 0,
                re_count = "const",
                mean = (0.485, 0.456, 0.406),
                std = (0.229, 0.224, 0.225),
            )
        self.preprocess_test = transforms.Compose(
                [
                    transforms.Resize(256, interpolation=transforms.InterpolationMode.BICUBIC),
                    transforms.CenterCrop(256),
                    transforms.ToTensor(),
                    transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
                ]
            )

        self.norm_mean = -5.081
        self.norm_std = 4.4849

        

    def __len__(self):
        return len(self.av_files)
    
    def get_image(self, filename, filename2=None, mix_lambda=1):
        if filename2 == None:
            img = Image.open(filename)
            if self.mode == "train":
                image_tensor = self.preprocess_train(img)
            else:
                image_tensor = self.preprocess_test(img)
            return image_tensor
        else:
            img1 = Image.open(filename)
            image_tensor1 = self.preprocess(img1)

            img2 = Image.open(filename2)
            image_tensor2 = self.preprocess(img2)

            image_tensor = mix_lambda * image_tensor1 + (1 - mix_lambda) * image_tensor2
            return image_tensor

    def __getitem__(self, idx):
        av_file = self.av_files[idx]

        # Text
        token_path = os.path.join(self.text_feature_path, av_file + '_token.npy')
        pm_path = os.path.join(self.text_feature_path, av_file + '_pm.npy')
        tokenizer = np.load(token_path)
        padding_mask = np.load(pm_path)
        tokenizer = torch.tensor(tokenizer)
        padding_mask = torch.tensor(padding_mask)

        visual_path = os.path.join(self.visual_feature_path, av_file)
        allimages = os.listdir(visual_path)
        image = self.get_image(os.path.join(visual_path, allimages[int(len(allimages) / 2)]))

        audio_path = os.path.join(self.audio_feature_path, av_file + '.npy')
        spectrogram = np.load(audio_path)
        spectrogram = torch.tensor(spectrogram)

        label = self.classes.index(self.data2class[av_file])

        
        return tokenizer, padding_mask, image, spectrogram, label, torch.LongTensor([idx])